import React, { useEffect, useState } from 'react';
import { styles } from './style';

import {
    SafeAreaView,
    Text,
    View,
    ScrollView,
    TouchableOpacity,
    Image,
    ActivityIndicator,
    RefreshControl,
    StatusBar,
    Alert,

} from 'react-native';

import { MaterialIcons } from '@expo/vector-icons';
import Load from '../../components/Load';
import { DrawerActions, useNavigation } from '@react-navigation/core';
import api from '../../services/api';
import { AnimatedCircularProgress } from 'react-native-circular-progress';

import { useIsFocused } from '@react-navigation/native';

export default function Home() {
    const navigation= useNavigation();
    const isFocused = useIsFocused();

    const [dados, setDados] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [usu, setUsu] = useState('');


    async function listarDados() {

        try {
            const user = await AsyncStorage.getItem('@user');
            const res = await api.get(`pam3etim/bd/dashboard/listar-cards.php?user=${user}`);
            setDados(res.data);

        } catch (error) {
            console.log("Erro ao Listar " + error);
        } finally {
            setIsLoading(false);
            setRefreshing(false);

        }
    }

    useEffect(() => {
        listarDados();
    }, [isFocused]);

    const onRefresh = () => {
        setRefreshing(true);
        listarDados();

    };


    return (
        <View style={{ flex: 1 }}>
            <StatusBar barStyle="light-content" />
            <View style={{ flex: 1 }}>
                <View style={styles.header}>
                    <View style={styles.containerHeader}>
                    <Image style={styles.neph2} source={require('../../assets/neph2.png')} />
                    <Image style={styles.lupa} source={require('../../assets/SeekPng.png')} />
                        <TouchableOpacity
                            style={styles.menu}
                            onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
                        >
                           
                        </TouchableOpacity>

                    </View>
                </View>

           
                    <View style={styles.Banner}>
                        <Text style={styles.caminhoneiroText} >Encontrar Caminhoneiros</Text>
                    </View> 
             
               

                    <ScrollView
                        style={{ flex: 1 }}
                        showsVerticalScrollIndicator={false}
                        nestedScrollEnabled={true}
                        refreshControl={
                            <RefreshControl
                                refreshing={refreshing}
                                onRefresh={onRefresh}
                            />
                        }
                    >

                    <View style={styles.containerBox}>
                          

                                
                            <TouchableOpacity onPress={() => navigation.navigate("CalcularFrete")}>
                                <View style={styles.calculo}>
                                    <Text style={styles.calculotxt}>Calcular Frete</Text>
                                </View>
                            </TouchableOpacity>

                      
                        
                        
                 


                                    <View style={styles.box}>
                                        <View>
                                           
                                        </View>
                                       <View>
                                            <Text style={styles.titulo}>José Da Serra</Text>
                                            <Text style={styles.txt2}>Registro - SP</Text>
                                            <Text style={styles.txt2}>Eixo: simples </Text>

                                            <Text style={styles.paragraph}>
                                                    {`  `}
                                            </Text>


                                            <Text style={styles.txt2}>Iveco 2945 - Branco</Text>
                                       </View>
                                       <View>
                                        <View style={styles.inv}></View>
                                       </View>

                                       <View>
                                        
                                         <Image style={styles.caminhao} source={require('../../assets/caminhao.png')} />
                                         
                                       </View>
                                    </View>
                              


                                <View>
                                    <View style={styles.box}>
                                        <View>
                                           
                                        </View>
                                       <View>
                                            <Text style={styles.titulo}>Maria do Rosário</Text>
                                            <Text style={styles.txt2}>Pariquera - Açu</Text>
                                            <Text style={styles.txt2}>Eixo: simples </Text>

                                            <Text style={styles.paragraph}>
                                                    {`  `}
                                            </Text>


                                            <Text style={styles.txt2}>Hyundai Sepra </Text>
                                       </View>
                                       <View>
                                        <View style={styles.inv}></View>
                                       </View>

                                       <View>
                                        
                                         <Image style={styles.caminhao} source={require('../../assets/caminhao.png')} />
                                         
                                       </View>
                                    </View>
                                </View>

                                <View>
                                    <View style={styles.box}>
                                        <View>
                                           
                                        </View>
                                       <View>
                                            <Text style={styles.titulo}>José Da Serra</Text>
                                            <Text style={styles.txt2}>Registro - SP</Text>
                                            <Text style={styles.txt2}>Eixo: simples </Text>

                                            <Text style={styles.paragraph}>
                                                    {`  `}
                                            </Text>


                                            <Text style={styles.txt2}>Iveco 2945 - Branco</Text>
                                       </View>
                                       <View>
                                        <View style={styles.inv}></View>
                                       </View>

                                       <View>
                                        
                                         <Image style={styles.caminhao} source={require('../../assets/caminhao.png')} />
                                         
                                       </View>
                                    </View>
                                </View>

                                <View>
                                    <View style={styles.box}>
                                        <View>
                                           
                                        </View>
                                       <View>
                                            <Text style={styles.titulo}>José Da Serra</Text>
                                            <Text style={styles.txt2}>Registro - SP</Text>
                                            <Text style={styles.txt2}>Eixo: simples </Text>

                                            <Text style={styles.paragraph}>
                                                    {`  `}
                                            </Text>


                                            <Text style={styles.txt2}>Iveco 2945 - Branco</Text>
                                       </View>
                                       <View>
                                        <View style={styles.inv}></View>
                                       </View>

                                       <View>
                                        
                                         <Image style={styles.caminhao} source={require('../../assets/caminhao.png')} />
                                         
                                       </View>
                                    </View>
                                </View>


                                
                           
                        </View>
                    </ScrollView>
                
            </View>
        </View>






    )
}
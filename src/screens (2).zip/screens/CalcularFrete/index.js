import React, { useState, useEffect } from 'react';
import {ScrollView, Platform, Alert, Picker, Text, TextInput, View, TouchableOpacity, ActivityIndicator } from 'react-native';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/core';
import { RectButton } from 'react-native-gesture-handler';
import { AntDesign, Ionicons } from '@expo/vector-icons';
import { styles } from './style';
import { Success } from '../../lotties/Success';
import { showMessage, hideMessage } from "react-native-flash-message";
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../../services/api';

 ParamList = {
    Detail: {
       id_reg: string,
        
    }
};

const CalcularFrete = FC= () => {
    const navigation = any = useNavigation();
    const route = useRoute<RouteProp<ParamList; 'Detail';
    const id_reg = route?.params?.id_reg;
    const [tipo, setTipo] = useState("");   
    const [rota, setRota] = useState("");   
    const [preco, setPreco] = useState("");   
    const [peso, setPeso] = useState("");
    const [tempo, setTempo] = useState("");
    const [sucess, setSucess] = useState(false);
    const [edit, setEdit] = useState(false);
    const [loading, setLoading] = useState(false);
   
    async function saveData() {            
       
              
           if (tipo == "" || rota == "" || peso == "" || preco == "" || tempo == "") {
            showMessage({
                message: "Erro ao Salvar",
                description: 'Preencha os Campos Obrigatórios!',
                type: "warning",
            });
            return;
        }

        try {
            const obj = {
                id: id_reg,
                tipo: tipo,
                rota: rota,               
                preco: preco,
                peso: peso,
                tempo: tempo,
               
                
            }
     
            const res = await api.post('pam3etim/bd/fretes/salvar.php', obj);

            if (res.data.sucesso === false) {
                showMessage({
                    message: "Erro ao Salvar",
                    description: res.data.mensagem,
                    type: "warning",
                    duration: 3000,
                });

                return;
            }

            setSucess(true);
            showMessage({
                message: "Salvo com Sucesso",
                description: "Registro Salvo",
                type: "success",
                duration: 800,
            });
            navigation.push("Home")

        } catch (error) {
            Alert.alert("Ops", "Alguma coisa deu errado, tente novamente.");
            setSucess(false);
        }
    }

    

    async function loadData() {
        
        try {
            setLoading(true);
            if (id_reg != "0") {
                const res = await api.get(`pam3etim/bd/fretes/listar_id.php?id=${id_reg}`);

                setTipo(res.data.dados.tipo);              
                setRota(res.data.dados.rota);
                setPreco(res.data.dados.preco);
                setPeso(res.data.dados.peso);
                setTempo(res.data.dados.tempo);
               
               
                setEdit(false);
                
            } else {
                setEdit(true);
            }
        } catch (error) {
            console.log('Error ao carregar os Dados');
        }
    }

     
        
    useEffect(() => {
        loadData().then(() => setLoading(false))
    }, [])

    if (loading === true) {
        return (
            <View style={{ flex: 1, backgroundColor: '#fff' }}>
                <ActivityIndicator style={{ marginTop: 100 }} color="#000" size="large" />
            </View>
        )
    }

    if (sucess) {
        return <Success />
    }
    

    return (
        <View style={{ flex: 1, marginTop: 20 }}>
            <View style={styles.Header}>
                <TouchableOpacity
                    style={styles.BackButton}
                    onPress={() => navigation.push("Caminhoneiros")}
                >
                    <Ionicons name="md-arrow-back-circle-outline" size={35} color="#484a4d" />

                </TouchableOpacity>
                {edit ?
                    <View style={styles.Title}>
                        <Text style={styles.TitleText}>Inserir Registro</Text>
                    </View>

                    :

                    <View style={styles.Title}>
                        <Text style={styles.TitleText}>Defina seu frete</Text>
                    </View>
                }

            </View>

             <ScrollView>   
            <View>
                <Text style={styles.TitleInputs}>Tipo de Frete:</Text>

                <TextInput
                    placeholder="Mudanças, transportes etc..."
                    onChangeText={(text) => setTipo(text)}
                    value={tipo}
                    style={styles.TextInput}
                />
            </View>


            <View>
                <Text style={styles.TitleInputs}>Rota:</Text>

                <TextInput
                    placeholder="Digite a rota que será realizada."
                    onChangeText={(text) => setRota(text)}
                    value={rota}
                    style={styles.TextInput}
                   
                />
            </View>



            
            <View>
                <Text style={styles.TitleInputs}>Preço calculado:</Text>

                <TextInput
                    placeholder="Digite o preço estimulado pelo calculador de fretes abaixo."
                    onChangeText={(text) => setPreco(text)}
                    value={preco}
                    style={styles.TextInput}
                   
                />
            </View>


            
            <View>
                <Text style={styles.TitleInputs}>Peso estimulado:</Text>

                <TextInput
                    placeholder="Peso"
                    onChangeText={(text) => setPeso(text)}
                    value={peso}
                    style={styles.TextInput}
                   
                />
            </View>

            <View>
                <Text style={styles.TitleInputs}>Tempo de transporte:</Text>

                <TextInput
                    placeholder="Em horas"
                    onChangeText={(text) => setTempo(text)}
                    value={tempo}
                    style={styles.TextInput}
                   
                />
            </View>


           
        
           
                <TouchableOpacity
                    style={styles.Button}
                    onPress={() => {
                        setSucess(true);
                        saveData();
                        setSucess(false);
                    }}
                >
                    <Text style={styles.ButtonText}>Salvar Registro</Text>
                </TouchableOpacity>

                </ScrollView>

               
    

        </View>
    );
}

export default CalcularFrete;
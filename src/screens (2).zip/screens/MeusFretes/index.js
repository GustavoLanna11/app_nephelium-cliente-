import React, { useEffect, useState } from 'react';
import { styles } from './style';

import {
    SafeAreaView,
    Text,
    View,
    ScrollView,
    TouchableOpacity,
    Image,
    ActivityIndicator,
    RefreshControl,
    StatusBar,
    Alert,

} from 'react-native';

import { MaterialIcons } from '@expo/vector-icons';
import Load from '../../components/Load';
import { DrawerActions, useNavigation } from '@react-navigation/core';
import api from '../../services/api';
import { AnimatedCircularProgress } from 'react-native-circular-progress';

import { useIsFocused } from '@react-navigation/native';

export default function Home() {
    const navigation= useNavigation();
    const isFocused = useIsFocused();

    const [dados, setDados] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [usu, setUsu] = useState('');


    async function listarDados() {

        try {
            const user = await AsyncStorage.getItem('@user');
            const res = await api.get(`pam3etim/bd/dashboard/listar-cards.php?user=${user}`);
            setDados(res.data);

        } catch (error) {
            console.log("Erro ao Listar " + error);
        } finally {
            setIsLoading(false);
            setRefreshing(false);

        }
    }

    useEffect(() => {
        listarDados();
    }, [isFocused]);

    const onRefresh = () => {
        setRefreshing(true);
        listarDados();

    };


    return (
        <View style={{ flex: 1 }}>
            <StatusBar barStyle="light-content" />
            <View style={{ flex: 1 }}>
            <View style={styles.header}>
                    <View style={styles.containerHeader}>

                        <TouchableOpacity
                            style={styles.menu}
                            onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
                        >
                           
                        </TouchableOpacity>

                        <Image style={styles.neph2} source={require('../../assets/neph2.png')} />
                        <Image style={styles.lupa} source={require('../../assets/SeekPng.png')} />
                    </View>
                </View>

                <View style={styles.Banner}>
                        <Text style={styles.caminhoneiroText}> Meus Fretes</Text>
                    </View> 

                    <ScrollView
                        style={{ flex: 1 }}
                        showsVerticalScrollIndicator={false}
                        nestedScrollEnabled={true}
                        refreshControl={
                            <RefreshControl
                                refreshing={refreshing}
                                onRefresh={onRefresh}
                            />
                        }
                    >

                        


                        <View style={styles.containerBox}>

                            <TouchableOpacity onPress={() => navigation.navigate("Usuario")}> 
                            </TouchableOpacity>
                                

                                <View style={styles.boxx}> 
                                <Text style={styles.T}>Frete em Andamento:</Text>
                                    <View style={styles.box2}>
                                    
                                        <View style={styles.textos}>
                                            <View><Text style={styles.titulo}>Informações do Frete</Text></View>
                                            <View style={styles.invisivel}></View>
                                            <View>
                                                <Text style={styles.sText}>Duração: 1 dia</Text> 
                                                <Text style={styles.sText}>Rota do Frete: Jacupiranga - São Paulo</Text>
                                                <Text style={styles.sText}>Valor: R$: 100.00</Text>
                                                <Text style={styles.sText}>Peso: 500 KG</Text>
                                                <Text style={styles.sText}>Tipo de Frete: Mudança</Text>

                                                <Text style={styles.paragraph}>
                                                    {`  `}
                                                </Text>
                                                <Text style={styles.paragraph}>
                                                    {`  `}
                                                </Text>

                                               


                                                <View><Text style={styles.titulo}>Informações do Caminhoneiro</Text></View>
                                                <View style={styles.invisivel}></View>
                                                <Text style={styles.sText}>Nome: João Guerra</Text> 
                                                <Text style={styles.sText}>Cidade: Jacupiranga - SP</Text>
                                                <Text style={styles.sText}>Caminhão: Mercedes Benz Bege 1990</Text>
                                                <Text style={styles.sText}>Eixo: Duplo - Tandem (9 à 13 toneladas)</Text>

                                                <Text style={styles.paragraph}>
                                                    {`  `}
                                                </Text>

                                                <TouchableOpacity onPress={() => navigation.navigate("Usuario")}>
                                                <View>
                                                    <View>
                                                        <View style={styles.BotaoBox}>
                                                            <Text style={styles.Botao}>
                                                            Rastrear Frete
                                                            </Text>
                                                        </View>
                                                    </View>
                                                </View>
                                                </TouchableOpacity>
                                                
                                                
                                            </View>
                                            
                                        </View>
                                    </View>
                                </View>

                                <View style={styles.boxx}> 
                                <Text style={styles.T}>Último Frete Concluído:</Text>
                                    <View style={styles.box2}>
                                        <View style={styles.textos}>
                                            <View><Text style={styles.titulo}>Informações do Frete</Text></View>
                                            <View style={styles.invisivel}></View>
                                            <View>
                                                <Text style={styles.sText}>Duração: 1 dia</Text> 
                                                <Text style={styles.sText}>Rota do Frete: Jacupiranga - São Paulo</Text>
                                                <Text style={styles.sText}>Valor: R$: 100.00</Text>
                                                <Text style={styles.sText}>Peso: 500 KG</Text>
                                                <Text style={styles.sText}>Tipo de Frete: Mudança</Text>

                                                <Text style={styles.paragraph}>
                                                    {`  `}
                                                </Text>
                                                <Text style={styles.paragraph}>
                                                    {`  `}
                                                </Text>

                                               


                                                <View><Text style={styles.titulo}>Informações do Caminhoneiro</Text></View>
                                                <View style={styles.invisivel}></View>
                                                <Text style={styles.sText}>Nome: João Guerra</Text> 
                                                <Text style={styles.sText}>Cidade: Jacupiranga - SP</Text>
                                                <Text style={styles.sText}>Caminhão: Mercedes Benz Bege 1990</Text>
                                                <Text style={styles.sText}>Eixo: Duplo - Tandem (9 à 13 toneladas)</Text>

                                                <Text style={styles.paragraph}>
                                                    {`  `}
                                                </Text>

                                                <TouchableOpacity onPress={() => navigation.navigate("Usuario")}>
                                                <View>
                                                    <View>
                                                        <View style={styles.BotaoBox}>
                                                            <Text style={styles.Botao}>
                                                            Rastrear Frete
                                                            </Text>
                                                        </View>
                                                    </View>
                                                </View>
                                                </TouchableOpacity>
                                            </View>
                                            
                                        </View>
                                    </View>
                                </View>


                        </View>


                    </ScrollView>
                
            </View>
        </View>






    )
                    }